document.addEventListener('DOMContentLoaded', () => {
    // Game state variables
    let gameBoard = [];
    let flippedCards = [];
    let matchedPairs = 0;
    let isLocked = false;
    let gameStarted = false;
    let gameTimer;
    let timerSeconds = 0;
    let boardSize = document.getElementById('game-board').dataset.size;
    let totalMatches = Math.floor((boardSize * boardSize - 1) / 2);
    let visitedCards = {};
    let draggedCard = null;
    
    // Elements
    const gameBoardElement = document.getElementById('game-board');
    const timerElement = document.getElementById('timer');
    const revisitsElement = document.getElementById('revisits');
    const matchesElement = document.getElementById('matches');
    const statusElement = document.getElementById('status-message');
    const countdownElement = document.getElementById('countdown');
    const resetButton = document.getElementById('reset-btn');
    const resultsModal = document.getElementById('results-modal');
    const playAgainButton = document.getElementById('play-again');
    
    // Initialize the game
    function initGame() {
        fetchGameBoard();
        resetButton.addEventListener('click', resetGame);
        playAgainButton.addEventListener('click', resetGame);
    }
    
    // Fetch the game board from the server
    function fetchGameBoard() {
        fetch('/generate_board')
            .then(response => response.json())
            .then(data => {
                gameBoard = data.board;
                renderGameBoard();
                startMemorizationPhase(data.display_time);
            })
            .catch(error => {
                console.error('Error fetching game board:', error);
                statusElement.textContent = 'Error loading game. Please try again.';
            });
    }
    
    // Render the game board
    function renderGameBoard() {
        gameBoardElement.innerHTML = '';
        
        gameBoard.forEach((row, rowIndex) => {
            row.forEach((cell, colIndex) => {
                const card = document.createElement('div');
                card.className = 'card';
                card.dataset.row = rowIndex;
                card.dataset.col = colIndex;
                card.dataset.icon = cell.icon;
                
                // Add center card class if it's the center card
                if (cell.is_center) {
                    card.classList.add('center-card');
                }
                
                // Create card inner structure for flip effect
                const cardInner = document.createElement('div');
                cardInner.className = 'card-inner';
                
                const cardFront = document.createElement('div');
                cardFront.className = 'card-front';
                const icon = document.createElement('i');
                icon.className = `fas ${cell.icon}`;
                cardFront.appendChild(icon);
                
                const cardBack = document.createElement('div');
                cardBack.className = 'card-back';
                
                cardInner.appendChild(cardFront);
                cardInner.appendChild(cardBack);
                card.appendChild(cardInner);
                
                // Add click event listener
                card.addEventListener('click', () => handleCardClick(card, rowIndex, colIndex));
                
                // Add drag and drop event listeners
                card.setAttribute('draggable', true);
                card.addEventListener('dragstart', handleDragStart);
                card.addEventListener('dragend', handleDragEnd);
                card.addEventListener('dragover', handleDragOver);
                card.addEventListener('dragenter', handleDragEnter);
                card.addEventListener('dragleave', handleDragLeave);
                card.addEventListener('drop', handleDrop);
                
                gameBoardElement.appendChild(card);
            });
        });
    }
    
    // Start the memorization phase
    function startMemorizationPhase(displayTime) {
        // Show all cards during memorization phase
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            card.classList.add('flipped');
        });
        
        statusElement.textContent = 'Memorize the board!';
        countdownElement.textContent = displayTime;
        
        // Start countdown
        let seconds = displayTime;
        const countdownInterval = setInterval(() => {
            seconds--;
            countdownElement.textContent = seconds;
            
            if (seconds <= 0) {
                clearInterval(countdownInterval);
                startGamePhase();
            }
        }, 1000);
    }
    
    // Start the game phase
    function startGamePhase() {
        // Hide all cards
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            card.classList.remove('flipped');
        });
        
        statusElement.textContent = 'Find the matching pairs!';
        countdownElement.textContent = '';
        
        // Start the game timer
        startTimer();
        gameStarted = true;
    }
    
    // Handle card click
    function handleCardClick(card, row, col) {
        // Ignore clicks if game hasn't started, board is locked, card is already flipped or matched
        if (!gameStarted || isLocked || card.classList.contains('flipped') || card.classList.contains('matched')) {
            return;
        }
        
        // Record visit to server
        recordCardVisit(row, col);
        
        // Check if this is a revisit
        const cardKey = `${row}-${col}`;
        if (visitedCards[cardKey]) {
            const revisits = parseInt(revisitsElement.textContent) + 1;
            revisitsElement.textContent = revisits;
        } else {
            visitedCards[cardKey] = true;
        }
        
        // Flip the card
        flipCard(card);
        
        // Check for matches
        checkForMatch();
    }
    
    // Record card visit to server
    function recordCardVisit(row, col) {
        fetch('/record_visit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                position: [row, col]
            })
        }).catch(error => {
            console.error('Error recording visit:', error);
        });
    }
    
    // Flip a card
    function flipCard(card) {
        card.classList.add('flipped');
        flippedCards.push(card);
    }
    
    // Check for a match
    function checkForMatch() {
        if (flippedCards.length !== 2) return;
        
        isLocked = true;
        const [firstCard, secondCard] = flippedCards;
        
        // Check if icons match
        if (firstCard.dataset.icon === secondCard.dataset.icon) {
            // It's a match
            handleMatch(firstCard, secondCard);
        } else {
            // Not a match
            setTimeout(() => {
                firstCard.classList.remove('flipped');
                secondCard.classList.remove('flipped');
                resetFlippedCards();
            }, 1000);
        }
    }
    
    // Handle a match
    function handleMatch(firstCard, secondCard) {
        firstCard.classList.add('matched');
        secondCard.classList.add('matched');
        
        // Make cards not draggable anymore
        firstCard.setAttribute('draggable', 'false');
        secondCard.setAttribute('draggable', 'false');
        
        matchedPairs++;
        matchesElement.textContent = matchedPairs;
        
        resetFlippedCards();
        
        // Check if game is complete
        if (matchedPairs === totalMatches) {
            endGame();
        }
    }
    
    // Reset flipped cards
    function resetFlippedCards() {
        flippedCards = [];
        isLocked = false;
    }
    
    // Drag and drop handlers
    function handleDragStart(event) {
        // Only allow dragging flipped cards that aren't matched
        if (!event.target.classList.contains('flipped') || 
            event.target.classList.contains('matched') ||
            event.target.classList.contains('center-card')) {
            event.preventDefault();
            return;
        }
        
        draggedCard = event.target;
        event.target.classList.add('dragging');
        
        // Set the data being dragged
        event.dataTransfer.setData('text/plain', '');
        event.dataTransfer.effectAllowed = 'move';
    }
    
    function handleDragEnd(event) {
        event.target.classList.remove('dragging');
    }
    
    function handleDragOver(event) {
        event.preventDefault();
    }
    
    function handleDragEnter(event) {
        // Only allow dropping on flipped cards that aren't matched
        if (event.target.classList.contains('card') && 
            event.target.classList.contains('flipped') && 
            !event.target.classList.contains('matched') &&
            !event.target.classList.contains('center-card')) {
            event.target.classList.add('droppable-hover');
        }
    }
    
    function handleDragLeave(event) {
        if (event.target.classList.contains('card')) {
            event.target.classList.remove('droppable-hover');
        }
    }
    
    function handleDrop(event) {
        event.preventDefault();
        
        const dropTarget = event.target.closest('.card');
        
        if (!dropTarget || !draggedCard || dropTarget === draggedCard) {
            return;
        }
        
        dropTarget.classList.remove('droppable-hover');
        
        // Check if the icons match
        if (draggedCard.dataset.icon === dropTarget.dataset.icon) {
            // It's a match
            handleMatch(draggedCard, dropTarget);
        } else {
            // Not a match - show briefly then flip back
            setTimeout(() => {
                draggedCard.classList.remove('flipped');
                dropTarget.classList.remove('flipped');
                resetFlippedCards();
            }, 1000);
        }
    }
    
    // Start the timer
    function startTimer() {
        gameTimer = setInterval(() => {
            timerSeconds++;
            updateTimerDisplay();
        }, 1000);
    }
    
    // Update the timer display
    function updateTimerDisplay() {
        const minutes = Math.floor(timerSeconds / 60);
        const seconds = timerSeconds % 60;
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // End the game
    function endGame() {
        clearInterval(gameTimer);
        
        // Calculate total revisits
        const revisits = parseInt(revisitsElement.textContent);
        
        // Send game stats to server
        fetch('/end_game', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                matches_found: matchedPairs,
            })
        })
        .then(response => response.json())
        .then(data => {
            // Display results
            document.getElementById('final-time').textContent = formatTime(data.duration);
            document.getElementById('final-revisits').textContent = data.revisits;
            document.getElementById('final-size').textContent = `${boardSize}×${boardSize}`;
            
            // Calculate performance rating
            const performanceElement = document.getElementById('performance-rating');
            const expectedTime = boardSize * boardSize * 1.5; // Expected seconds based on board size
            
            let rating;
            if (data.duration < expectedTime && data.revisits < boardSize) {
                rating = 'Excellent! Your memory is extraordinary!';
                performanceElement.className = 'performance-rating excellent';
            } else if (data.duration < expectedTime * 1.5 && data.revisits < boardSize * 2) {
                rating = 'Good job! Your memory is impressive!';
                performanceElement.className = 'performance-rating good';
            } else if (data.duration < expectedTime * 2 && data.revisits < boardSize * 3) {
                rating = 'Not bad! Keep practicing to improve your memory.';
                performanceElement.className = 'performance-rating average';
            } else {
                rating = 'You can do better! Try again to improve your memory skills.';
                performanceElement.className = 'performance-rating poor';
            }
            
            performanceElement.textContent = rating;
            
            // Show the modal
            resultsModal.classList.add('show');
        })
        .catch(error => {
            console.error('Error ending game:', error);
        });
    }
    
    // Format time for display
    function formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = Math.round(seconds % 60);
        return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    
    // Reset the game
    function resetGame() {
        // Reset game state
        flippedCards = [];
        matchedPairs = 0;
        isLocked = false;
        gameStarted = false;
        timerSeconds = 0;
        visitedCards = {};
        
        // Reset UI
        updateTimerDisplay();
        matchesElement.textContent = '0';
        revisitsElement.textContent = '0';
        
        // Clear timer
        clearInterval(gameTimer);
        
        // Hide modal
        resultsModal.classList.remove('show');
        
        // Start a new game
        fetchGameBoard();
    }
    
    // Start the game initialization
    initGame();
});