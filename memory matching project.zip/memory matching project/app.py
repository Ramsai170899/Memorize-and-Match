from flask import Flask, render_template, request, jsonify, session
import os
import random
import secrets
from datetime import datetime

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Dictionary of possible images for the game (using Font Awesome icons for simplicity)
ICONS = [
    'fa-apple', 'fa-car', 'fa-house', 'fa-star', 'fa-heart', 
    'fa-diamond', 'fa-bell', 'fa-gift', 'fa-leaf', 'fa-music',
    'fa-key', 'fa-paw', 'fa-plane', 'fa-rocket', 'fa-sun',
    'fa-tree', 'fa-umbrella', 'fa-coffee', 'fa-bicycle', 'fa-bus',
    'fa-camera', 'fa-futbol', 'fa-moon', 'fa-pizza-slice', 'fa-anchor',
    'fa-book', 'fa-cloud', 'fa-envelope', 'fa-fire', 'fa-globe',
    'fa-laptop', 'fa-mountain', 'fa-palette', 'fa-robot', 'fa-ship',
    'fa-train', 'fa-trophy', 'fa-user', 'fa-wifi', 'fa-wine-glass',
    'fa-graduation-cap', 'fa-guitar', 'fa-lemon', 'fa-crown', 'fa-ghost',
    'fa-fish', 'fa-ice-cream', 'fa-phone', 'fa-gamepad', 'fa-basketball'
]

@app.route('/')
def index():
    """Render the homepage with game configuration options"""
    return render_template('index.html')

@app.route('/game')
def game():
    """Render the game page"""
    board_size = int(request.args.get('size', 5))
    
    # Ensure board size is within allowed range
    if board_size < 5:
        board_size = 5
    elif board_size > 10:
        board_size = 10
    
    session['board_size'] = board_size
    
    return render_template('game.html', board_size=board_size)

@app.route('/generate_board')
def generate_board():
    """Generate a board with random pairs of icons"""
    board_size = session.get('board_size', 5)
    total_cells = board_size * board_size
    pairs_needed = (total_cells - 1) // 2  # Account for center cell
    
    # Select random icons from our collection
    selected_icons = random.sample(ICONS, pairs_needed)
    
    # Double them to create pairs
    board_icons = selected_icons * 2
    
    # If board has odd number of cells, we'll have one cell left (the center)
    if total_cells % 2 == 1:
        board_icons.append("fa-brain")  # Center icon is always a brain
    
    # Shuffle the icons
    random.shuffle(board_icons)
    
    # Create 2D board
    board = []
    icon_index = 0
    
    for row in range(board_size):
        current_row = []
        for col in range(board_size):
            # If it's the center cell, place the brain icon
            if board_size % 2 == 1 and row == board_size // 2 and col == board_size // 2:
                current_row.append({
                    'icon': 'fa-brain',
                    'is_center': True,
                    'position': (row, col)
                })
            else:
                current_row.append({
                    'icon': board_icons[icon_index],
                    'is_center': False,
                    'position': (row, col)
                })
                icon_index += 1
        board.append(current_row)
    
    # Save the current time to measure game duration
    session['game_start_time'] = datetime.now().isoformat()
    session['visit_counts'] = {}  # To track revisits
    
    return jsonify({
        'board': board,
        'display_time': board_size * 2  # Display time equals double the board size in seconds
    })

@app.route('/record_visit', methods=['POST'])
def record_visit():
    """Record when a user revisits a cell"""
    data = request.json
    position = data.get('position')
    position_str = f"{position[0]}-{position[1]}"
    
    visit_counts = session.get('visit_counts', {})
    visit_counts[position_str] = visit_counts.get(position_str, 0) + 1
    session['visit_counts'] = visit_counts
    
    return jsonify({'success': True})

@app.route('/end_game', methods=['POST'])
def end_game():
    """Record the end of a game and calculate stats"""
    data = request.json
    matches_found = data.get('matches_found', 0)
    
    start_time = datetime.fromisoformat(session.get('game_start_time'))
    end_time = datetime.now()
    duration_seconds = (end_time - start_time).total_seconds()
    
    visit_counts = session.get('visit_counts', {})
    total_revisits = sum(count - 1 for count in visit_counts.values() if count > 1)
    
    results = {
        'duration': round(duration_seconds, 1),
        'revisits': total_revisits,
        'board_size': session.get('board_size', 5),
        'matches_found': matches_found
    }
    
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)